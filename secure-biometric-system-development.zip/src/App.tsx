import { useState, useCallback, useMemo, useEffect, type ReactNode } from "react";

// ─────────────────────────────────────────────────────────────
// Types & Interfaces
// ─────────────────────────────────────────────────────────────
type View =
  | "dashboard"
  | "enrollment"
  | "authentication"
  | "logs"
  | "alerts"
  | "users"
  | "settings";

type BiometricType = "fingerprint" | "iris" | "face" | "voice" | "palm";
type AccessResult = "granted" | "denied" | "pending" | "lockout";
type AlertSeverity = "critical" | "warning" | "info" | "success";

interface UserIdentity {
  id: string;
  name: string;
  role: "admin" | "operator" | "user" | "guest";
  department: string;
  biometrics: Record<BiometricType, boolean>;
  enrolledAt: string;
  lastSeen: string;
  status: "active" | "suspended" | "pending";
  clearanceLevel: 1 | 2 | 3 | 4 | 5;
  badgeNumber: string;
  photoSeed: number;
}

interface AccessLog {
  id: string;
  userId: string;
  userName: string;
  method: BiometricType;
  result: AccessResult;
  timestamp: string;
  point: string;
  deviceId: string;
  confidence: number;
  reason?: string;
}

interface SecurityAlert {
  id: string;
  severity: AlertSeverity;
  title: string;
  message: string;
  timestamp: string;
  resolved: boolean;
  source: string;
  metadata?: Record<string, string>;
}

interface Device {
  id: string;
  name: string;
  location: string;
  type: string;
  status: "online" | "offline" | "maintenance";
  lastHeartbeat: string;
  firmwareVersion: string;
}

interface SystemStats {
  totalEnrolled: number;
  activeToday: number;
  successRate: number;
  failedAttempts: number;
  lockedAccounts: number;
  alertsCount: number;
  avgResponseTime: number;
  systemUptime: string;
}

interface AlertRule {
  id: string;
  name: string;
  description: string;
  severity: AlertSeverity;
  enabled: boolean;
  triggerCount: number;
}

// ─────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────
const DEPARTMENTS = [
  "Engineering", "Research & Development", "Security Operations",
  "Human Resources", "Finance", "Data Center", "Executive Wing",
  "Legal", "IT Administration", "Medical Bay",
];
const ROLES: { label: string; value: UserIdentity["role"] }[] = [
  { label: "Administrator", value: "admin" },
  { label: "Operator", value: "operator" },
  { label: "Standard User", value: "user" },
  { label: "Guest", value: "guest" },
];
const CLEARANCE_LEVELS = [
  { level: 1, label: "Level 1 - Public" },
  { level: 2, label: "Level 2 - Internal" },
  { level: 3, label: "Level 3 - Restricted" },
  { level: 4, label: "Level 4 - High Security" },
  { level: 5, label: "Level 5 - Top Secret" },
];
const BIOMETRIC_LABELS: Record<BiometricType, { label: string; icon: string }> = {
  fingerprint: { label: "Fingerprint", icon: "🖐️" },
  iris: { label: "Iris Scan", icon: "👁️" },
  face: { label: "Facial Recognition", icon: "🙂" },
  voice: { label: "Voice Print", icon: "🎙️" },
  palm: { label: "Palm Vein", icon: "🤚" },
};

// ─────────────────────────────────────────────────────────────
// Seed data helpers
// ─────────────────────────────────────────────────────────────
function generateId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

function timeAgo(ts: string): string {
  const diff = Date.now() - new Date(ts).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function formatDate(ts: string): string {
  return new Date(ts).toLocaleString("en-US", {
    month: "short", day: "2-digit", year: "numeric",
    hour: "2-digit", minute: "2-digit", hour12: false,
  });
}

function confidenceColor(conf: number): string {
  if (conf >= 90) return "text-emerald-600 bg-emerald-50";
  if (conf >= 70) return "text-amber-600 bg-amber-50";
  if (conf >= 50) return "text-orange-600 bg-orange-50";
  return "text-red-600 bg-red-50";
}

function severityConfig(s: AlertSeverity) {
  switch (s) {
    case "critical":
      return { bg: "bg-red-50", border: "border-red-200", dot: "bg-red-500", text: "text-red-700", badge: "bg-red-100 text-red-700 ring-red-200" };
    case "warning":
      return { bg: "bg-amber-50", border: "border-amber-200", dot: "bg-amber-500", text: "text-amber-700", badge: "bg-amber-100 text-amber-700 ring-amber-200" };
    case "info":
      return { bg: "bg-sky-50", border: "border-sky-200", dot: "bg-sky-500", text: "text-sky-700", badge: "bg-sky-100 text-sky-700 ring-sky-200" };
    case "success":
      return { bg: "bg-emerald-50", border: "border-emerald-200", dot: "bg-emerald-500", text: "text-emerald-700", badge: "bg-emerald-100 text-emerald-700 ring-emerald-200" };
  }
}

function accessResultBadge(r: AccessResult): string {
  switch (r) {
    case "granted": return "bg-emerald-50 text-emerald-700 ring-emerald-200";
    case "denied": return "bg-red-50 text-red-700 ring-red-200";
    case "pending": return "bg-amber-50 text-amber-700 ring-amber-200";
    case "lockout": return "bg-slate-100 text-slate-700 ring-slate-300";
  }
}

const initialUsers: UserIdentity[] = [
  { id: "U-1001", name: "Dr. Sarah Chen", role: "admin", department: "Executive Wing", biometrics: { fingerprint: true, iris: true, face: true, voice: true, palm: true }, enrolledAt: "2024-01-15T09:00:00Z", lastSeen: "2025-06-14T08:32:00Z", status: "active", clearanceLevel: 5, badgeNumber: "A-1001", photoSeed: 101 },
  { id: "U-1002", name: "James Rivera", role: "operator", department: "Security Operations", biometrics: { fingerprint: true, iris: true, face: true, voice: false, palm: true }, enrolledAt: "2024-02-20T11:30:00Z", lastSeen: "2025-06-14T07:45:00Z", status: "active", clearanceLevel: 4, badgeNumber: "S-1002", photoSeed: 102 },
  { id: "U-1003", name: "Aisha Patel", role: "user", department: "Research & Development", biometrics: { fingerprint: true, iris: false, face: true, voice: true, palm: false }, enrolledAt: "2024-03-10T14:15:00Z", lastSeen: "2025-06-13T18:20:00Z", status: "active", clearanceLevel: 3, badgeNumber: "R-1003", photoSeed: 103 },
  { id: "U-1004", name: "Marcus Webb", role: "guest", department: "IT Administration", biometrics: { fingerprint: true, iris: false, face: false, voice: false, palm: false }, enrolledAt: "2024-05-05T10:00:00Z", lastSeen: "2025-05-28T16:00:00Z", status: "suspended", clearanceLevel: 1, badgeNumber: "G-1004", photoSeed: 104 },
  { id: "U-1005", name: "Elena Kowalski", role: "user", department: "Data Center", biometrics: { fingerprint: true, iris: true, face: true, voice: true, palm: true }, enrolledAt: "2024-04-01T08:00:00Z", lastSeen: "2025-06-14T09:10:00Z", status: "active", clearanceLevel: 4, badgeNumber: "D-1005", photoSeed: 105 },
  { id: "U-1006", name: "Sanjay Mehta", role: "operator", department: "Engineering", biometrics: { fingerprint: true, iris: false, face: true, voice: true, palm: true }, enrolledAt: "2024-06-18T13:00:00Z", lastSeen: "2025-06-12T20:05:00Z", status: "active", clearanceLevel: 3, badgeNumber: "E-1006", photoSeed: 106 },
];

const initialLogs: AccessLog[] = [
  { id: "L-9001", userId: "U-1001", userName: "Dr. Sarah Chen", method: "face", result: "granted", timestamp: "2025-06-14T09:15:00Z", point: "Main Entrance", deviceId: "DEV-01", confidence: 98.7 },
  { id: "L-9002", userId: "U-1002", userName: "James Rivera", method: "fingerprint", result: "granted", timestamp: "2025-06-14T09:10:00Z", point: "Server Room B", deviceId: "DEV-03", confidence: 99.1 },
  { id: "L-9003", userId: "U-9999", userName: "Unknown Subject", method: "iris", result: "denied", timestamp: "2025-06-14T08:58:00Z", point: "Data Center", deviceId: "DEV-02", confidence: 23.4, reason: "No biometric match found" },
  { id: "L-9004", userId: "U-1005", userName: "Elena Kowalski", method: "palm", result: "granted", timestamp: "2025-06-14T08:55:00Z", point: "Research Lab", deviceId: "DEV-04", confidence: 96.2 },
  { id: "L-9005", userId: "U-1003", userName: "Aisha Patel", method: "voice", result: "denied", timestamp: "2025-06-14T08:40:00Z", point: "Executive Wing", deviceId: "DEV-01", confidence: 45.1, reason: "Insufficient clearance level" },
  { id: "L-9006", userId: "U-1006", userName: "Sanjay Mehta", method: "face", result: "granted", timestamp: "2025-06-13T20:05:00Z", point: "Engineering Block", deviceId: "DEV-05", confidence: 97.8 },
  { id: "L-9007", userId: "U-1002", userName: "James Rivera", method: "fingerprint", result: "denied", timestamp: "2025-06-13T18:30:00Z", point: "Server Room A", deviceId: "DEV-03", confidence: 34.2, reason: "Biometric quality below threshold" },
  { id: "L-9008", userId: "U-1001", userName: "Dr. Sarah Chen", method: "iris", result: "granted", timestamp: "2025-06-13T15:00:00Z", point: "Executive Vault", deviceId: "DEV-01", confidence: 99.5 },
  { id: "L-9009", userId: "U-9998", userName: "Unknown Subject", method: "face", result: "denied", timestamp: "2025-06-13T14:20:00Z", point: "Main Entrance", deviceId: "DEV-01", confidence: 12.8, reason: "Multiple failed attempts detected" },
  { id: "L-9010", userId: "U-1005", userName: "Elena Kowalski", method: "fingerprint", result: "pending", timestamp: "2025-06-14T09:16:00Z", point: "Data Center", deviceId: "DEV-02", confidence: 72.3, reason: "Awaiting secondary verification" },
];

const initialAlerts: SecurityAlert[] = [
  { id: "ALT-701", severity: "critical", title: "Unauthorized Access Attempt", message: "Multiple failed authentication attempts detected at Data Center entry point.", timestamp: "2025-06-14T08:58:00Z", resolved: false, source: "DEV-02 · Data Center", metadata: { attempts: "7", window: "15 min" } },
  { id: "ALT-702", severity: "warning", title: "Biometric Sensor Degradation", message: "Iris scanner on DEV-01 Main Entrance reporting decreased signal quality.", timestamp: "2025-06-14T07:00:00Z", resolved: false, source: "DEV-01 · Main Entrance", metadata: { signal: "-18%" } },
  { id: "ALT-703", severity: "info", title: "Scheduled Maintenance Window", message: "Server Room B devices undergoing firmware update. ETA: 2 hours.", timestamp: "2025-06-14T06:00:00Z", resolved: false, source: "System", metadata: { devices: "3" } },
  { id: "ALT-704", severity: "success", title: "System Recovery Complete", message: "Backup authentication cluster restored to full operational capacity.", timestamp: "2025-06-14T05:30:00Z", resolved: true, source: "Cluster Manager", metadata: { recoveryTime: "12 min" } },
  { id: "ALT-705", severity: "warning", title: "Account Lockout Policy Triggered", message: "User U-1004 (Marcus Webb) locked out due to 5 consecutive failed attempts.", timestamp: "2025-06-13T17:45:00Z", resolved: true, source: "Auth Engine", metadata: { lockedUntil: "17:50 UTC" } },
];

const initialDevices: Device[] = [
  { id: "DEV-01", name: "Main Entrance Kiosk", location: "Main Entrance", type: "Multi-Modal Scanner", status: "online", lastHeartbeat: "2025-06-14T09:15:00Z", firmwareVersion: "4.2.1" },
  { id: "DEV-02", name: "Data Center Entry", location: "Data Center", type: "Iris + Fingerprint", status: "online", lastHeartbeat: "2025-06-14T09:14:00Z", firmwareVersion: "4.1.8" },
  { id: "DEV-03", name: "Server Room Terminal", location: "Server Room B", type: "Fingerprint Only", status: "maintenance", lastHeartbeat: "2025-06-14T06:00:00Z", firmwareVersion: "4.0.3" },
  { id: "DEV-04", name: "Research Lab Gate", location: "Research Lab", type: "Palm Vein Scanner", status: "online", lastHeartbeat: "2025-06-14T09:15:00Z", firmwareVersion: "4.2.0" },
  { id: "DEV-05", name: "Engineering Block Entry", location: "Engineering Block", type: "Face Recognition", status: "online", lastHeartbeat: "2025-06-14T09:13:00Z", firmwareVersion: "4.2.1" },
];

const initialAlertRules: AlertRule[] = [
  { id: "RULE-01", name: "Failed Attempt Threshold", description: "Alert after 3+ failed attempts within 10 minutes", severity: "warning", enabled: true, triggerCount: 12 },
  { id: "RULE-02", name: "Device Offline Detection", description: "Alert when device heartbeat is lost for >5 minutes", severity: "critical", enabled: true, triggerCount: 3 },
  { id: "RULE-03", name: "Unusual Access Time", description: "Alert for access attempts outside 06:00–23:00 UTC", severity: "warning", enabled: false, triggerCount: 0 },
  { id: "RULE-04", name: "Privilege Escalation Attempt", description: "Alert when user attempts access above their clearance level", severity: "critical", enabled: true, triggerCount: 5 },
];

// ─────────────────────────────────────────────────────────────
// UI Primitives
// ─────────────────────────────────────────────────────────────
const baseBtn =
  "inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-40 disabled:cursor-not-allowed";
const primaryBtn = `${baseBtn} bg-indigo-600 text-white hover:bg-indigo-700 focus:ring-indigo-500 shadow-sm`;
const secondaryBtn = `${baseBtn} bg-white text-slate-700 hover:bg-slate-50 border border-slate-200 focus:ring-slate-400 shadow-sm`;
const dangerBtn = `${baseBtn} bg-red-600 text-white hover:bg-red-700 focus:ring-red-500 shadow-sm`;
const ghostBtn = `${baseBtn} text-slate-600 hover:text-slate-900 hover:bg-slate-100`;
const xsBtn = "inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold transition-colors";

function Card({ children, className = "", onClick, ...rest }: { children: ReactNode; className?: string; onClick?: () => void; [key: string]: unknown }) {
  return (
    <div
      {...rest}
      onClick={onClick}
      className={`rounded-xl border border-slate-200 bg-white shadow-sm ${className ?? ""}`}
    >
      {children}
    </div>
  );
}

function StatCard({ label, value, sub, icon, color }:
  { label: string; value: string | number; sub?: string; icon: ReactNode; color: string }) {
  return (
    <Card className="p-5 flex items-center gap-4">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${color} text-xl`}>{icon}</div>
      <div className="min-w-0">
        <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
        <p className="text-2xl font-bold text-slate-900 leading-tight">{value}</p>
        {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
      </div>
    </Card>
  );
}

// ─────────────────────────────────────────────────────────────
// Main App Component
// ─────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState<View>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // ── Data State ──────────────────────────────────────────────
  const [users, setUsers] = useState<UserIdentity[]>(initialUsers);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [, _setLogs] = useState<AccessLog[]>(initialLogs);
  const [logs] = useState<AccessLog[]>(initialLogs);
  const [alerts, setAlerts] = useState<SecurityAlert[]>(initialAlerts);
  const [devices] = useState<Device[]>(initialDevices);
  const [alertRules, setAlertRules] = useState<AlertRule[]>(initialAlertRules);

  // ── Auth simulation state ──────────────────────────────────
  const [authMethod, setAuthMethod] = useState<BiometricType>("face");
  const [authScanning, setAuthScanning] = useState(false);
  const [authResult, setAuthResult] = useState<AccessResult | null>(null);
  const [authUserName, setAuthUserName] = useState("");
  const [authConfidence, setAuthConfidence] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<number | null>(null);

  // ── Enrollment state ───────────────────────────────────────
  const [enrollName, setEnrollName] = useState("");
  const [enrollRole, setEnrollRole] = useState<UserIdentity["role"]>("user");
  const [enrollDept, setEnrollDept] = useState(DEPARTMENTS[0]);
  const [enrollClearance, setEnrollClearance] = useState<1 | 2 | 3 | 4 | 5>(2);
  const [enrollBiometrics, setEnrollBiometrics] = useState({
    fingerprint: false, face: false, iris: false, voice: false, palm: false,
  } as Record<BiometricType, boolean>);
  const [enrollScanning, setEnrollScanning] = useState<BiometricType | null>(null);
  const [enrollProgress, setEnrollProgress] = useState<Record<string, number>>({});

  // ── Log filter state ───────────────────────────────────────
  const [logFilter, setLogFilter] = useState<{ result?: string; method?: string; userId?: string }>({});
  const [logSearch, setLogSearch] = useState("");

  // ── Settings state ─────────────────────────────────────────
  const [lockoutThreshold, setLockoutThreshold] = useState(5);
  const [lockoutDuration, setLockoutDuration] = useState(5);
  const [minConfidence, setMinConfidence] = useState(75);
  const [mfaRequired, setMfaRequired] = useState(true);
  const [auditRetention, setAuditRetention] = useState(90);
  const [autoLock, setAutoLock] = useState(true);
  const [tamperDetection, setTamperDetection] = useState(true);
  const [encryptionAtRest, setEncryptionAtRest] = useState(true);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // ── Alert modal ────────────────────────────────────────────
  const [selectedAlert, setSelectedAlert] = useState<SecurityAlert | null>(null);

  // ── User detail modal ──────────────────────────────────────
  const [selectedUser, setSelectedUser] = useState<UserIdentity | null>(null);
  const [userTab, setUserTab] = useState<"info" | "logs" | "settings">("info");

  // ─── Behavior: auto-lock countdown ─────────────────────────
  useEffect(() => {
    if (!lockoutUntil) return;
    const check = setInterval(() => {
      if (Date.now() > lockoutUntil) setLockoutUntil(null);
    }, 1000);
    return () => clearInterval(check);
  }, [lockoutUntil]);

  // ─── Simulate biometric scan ───────────────────────────────
  const simulateScan = useCallback(
    (): Promise<{ confidence: number; matched: boolean }> =>
      new Promise((resolve) => {
        setTimeout(() => {
          const conf = Math.floor(60 + Math.random() * 40);
          resolve({ confidence: conf, matched: conf >= minConfidence });
        }, 600);
      }),
    [minConfidence],
  );

  // ─────────────────────────────────────────────────────────────
  // Stats computation
  // ─────────────────────────────────────────────────────────────
  const systemStats: SystemStats = useMemo(() => {
    const totalEnrolled = users.length;
    const activeToday = users.filter((u) => Date.now() - new Date(u.lastSeen).getTime() < 24 * 60 * 60 * 1000).length;
    const total = logs.length;
    const success = logs.filter((l) => l.result === "granted").length;
    const failedAttempts = logs.filter((l) => l.result === "denied").length;
    const lockedAccounts = users.filter((u) => u.status === "suspended").length + (lockoutUntil ? 1 : 0);
    const unresolvedAlerts = alerts.filter((a) => !a.resolved).length;
    return {
      totalEnrolled, activeToday,
      successRate: total ? Math.round((success / total) * 100) : 0,
      failedAttempts, lockedAccounts, alertsCount: unresolvedAlerts,
      avgResponseTime: 187 + Math.floor(Math.random() * 25),
      systemUptime: "99.97%",
    };
  }, [users, logs, alerts, lockoutUntil]);

  // ─────────────────────────────────────────────────────────────
  // Handlers: Authentication
  // ─────────────────────────────────────────────────────────────
  const handleAuthScan = useCallback(async () => {
    if (lockoutUntil && Date.now() < lockoutUntil) return;
    setAuthScanning(true);
    setAuthResult(null);
    setAuthConfidence(0);

    for (let i = 0; i <= 40; i++) {
      await new Promise((r) => setTimeout(r, 50));
      setAuthConfidence(Math.round((i / 40) * 100));
    }

    const { confidence, matched } = await simulateScan();

    if (!matched) {
      setAuthResult("denied");
      setAuthConfidence(confidence);
    } else {
      const activeUsers = users.filter((u) => u.status === "active");
      const user = activeUsers[Math.floor(Math.random() * activeUsers.length)];
      if (user) { setAuthUserName(user.name); setAuthResult("granted"); }
      else setAuthResult("denied");
      setAuthConfidence(confidence);
    }
    setAuthScanning(false);
  }, [lockoutUntil, simulateScan, users]);

  // ─────────────────────────────────────────────────────────────
  // Handlers: Enrollment
  // ─────────────────────────────────────────────────────────────
  const toggleEnrollBiometric = useCallback((type: BiometricType) => {
    setEnrollBiometrics((prev) => ({ ...prev, [type]: !prev[type] }));
  }, []);

  const scanBiometricForEnroll = useCallback(
    async (type: BiometricType) => {
      setEnrollScanning(type);
      for (let i = 0; i <= 30; i++) {
        await new Promise((r) => setTimeout(r, 40));
        setEnrollProgress((p) => ({ ...p, [type]: Math.round((i / 30) * 100) }));
      }
      toggleEnrollBiometric(type);
      setEnrollScanning(null);
    },
    [toggleEnrollBiometric],
  );

  const handleEnroll = useCallback(() => {
    if (!enrollName.trim()) return;
    const newUser: UserIdentity = {
      id: generateId("U"),
      name: enrollName.trim(),
      role: enrollRole,
      department: enrollDept,
      biometrics: { ...enrollBiometrics },
      enrolledAt: new Date().toISOString(),
      lastSeen: new Date().toISOString(),
      status: "active" as const,
      clearanceLevel: enrollClearance,
      badgeNumber: `${enrollRole === "admin" ? "A" : enrollRole === "operator" ? "S" : enrollRole === "user" ? "R" : "G"}-${generateId("B")}`,
      photoSeed: Math.floor(Math.random() * 1000) + 200,
    };
    setUsers((prev) => [newUser, ...prev]);
    setEnrollName("");
    setEnrollRole("user");
    setEnrollDept(DEPARTMENTS[0]);
    setEnrollClearance(2);
    setEnrollBiometrics({ fingerprint: false, face: false, iris: false, voice: false, palm: false });
    setEnrollProgress({});
    setView("users");
  }, [enrollName, enrollDept, enrollRole, enrollClearance, enrollBiometrics]);

  // ─────────────────────────────────────────────────────────────
  // Sidebar
  // ─────────────────────────────────────────────────────────────
  const NavLink = (
    v: View,
    icon: ReactNode,
    label: string,
    onClick?: () => void,
  ) => (
    <button
      onClick={() => { setView(v); setSidebarOpen(false); if (onClick) onClick(); }}
      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
        view === v ? "bg-indigo-50 text-indigo-700" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
      }`}
    >
      <span className="text-lg">{icon}</span>
      {label}
    </button>
  );

  const sidebar = (
    <aside className="flex h-screen w-64 flex-col border-r border-slate-200 bg-white">
      <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-lg font-bold text-white shadow-md">
          BS
        </div>
        <div>
          <h1 className="text-base font-bold text-slate-900 leading-none">BioShield</h1>
          <p className="text-xs text-slate-500 mt-0.5">Security v4.2</p>
        </div>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto p-3">
        {[
          { v: "dashboard" as View, icon: "📊", label: "Dashboard" },
          { v: "authentication" as View, icon: "🔐", label: "Authentication" },
          { v: "enrollment" as View, icon: "👤", label: "Enrollment" },
          { v: "users" as View, icon: "👥", label: "Users" },
          { v: "logs" as View, icon: "📋", label: "Access Logs" },
          { v: "alerts" as View, icon: "🔔", label: "Alert Center" },
          { v: "settings" as View, icon: "⚙️", label: "Settings" },
        ].map(({ v, icon, label }) => NavLink(v, icon, label))}
      </nav>
      <div className="border-t border-slate-200 p-4 space-y-3">
        <div className="rounded-lg bg-slate-50 p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-700">System Status</span>
            <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500" />
          </div>
          <p className="text-xs text-slate-500">All systems operational</p>
          <p className="text-xs text-slate-400 mt-1">Uptime: {systemStats.systemUptime}</p>
        </div>
        <div className="rounded-lg bg-slate-50 p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-700">Devices Online</span>
            <span className="text-xs font-bold text-indigo-600">
              {devices.filter((d) => d.status === "online").length}/{devices.length}
            </span>
          </div>
          {devices.slice(0, 3).map((dev) => (
            <div key={dev.id} className="flex items-center justify-between py-1">
              <span className="text-xs text-slate-500 truncate flex-1">{dev.name}</span>
              <span className={`h-1.5 w-1.5 rounded-full ${
                dev.status === "online" ? "bg-emerald-500"
                : dev.status === "maintenance" ? "bg-amber-500"
                : "bg-red-500"
              }`} />
            </div>
          ))}
        </div>
      </div>
    </aside>
  );

  // ─────────────────────────────────────────────────────────────
  // View: Dashboard
  // ─────────────────────────────────────────────────────────────
  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Enrolled Users" value={systemStats.totalEnrolled} sub={`${systemStats.activeToday} active today`} icon="👥" color="bg-indigo-50" />
        <StatCard label="Auth Success Rate" value={`${systemStats.successRate}%`} sub="Last 24 hours" icon="✅" color="bg-emerald-50" />
        <StatCard label="Failed Attempts" value={systemStats.failedAttempts} sub="Last 24 hours" icon="🚫" color="bg-red-50" />
        <StatCard label="Active Alerts" value={systemStats.alertsCount} sub="Unresolved" icon="🔔" color="bg-amber-50" />
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <h3 className="text-sm font-bold text-slate-900">Recent Access Activity</h3>
            <button onClick={() => setView("logs")} className={ghostBtn}>View all →</button>
          </div>
          <div className="divide-y divide-slate-100">
            {logs.slice(0, 5).map((log) => (
              <div key={log.id} className="flex items-center gap-4 px-5 py-3">
                <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-base ${
                  log.result === "granted" ? "bg-emerald-50" : "bg-red-50"
                }`}>
                  {log.result === "granted" ? "✅" : "❌"}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900 truncate">{log.userName}</p>
                  <p className="text-xs text-slate-500 truncate">
                    {BIOMETRIC_LABELS[log.method].label} · {log.point}
                  </p>
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${
                  log.result === "granted"
                    ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                    : "bg-red-50 text-red-700 ring-red-200"
                }`}>
                  {log.result.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
            <h3 className="text-sm font-bold text-slate-900">Active Alerts</h3>
            <button onClick={() => setView("alerts")} className={ghostBtn}>View all →</button>
          </div>
          <div className="divide-y divide-slate-100">
            {alerts.filter((a) => !a.resolved).slice(0, 5).map((alert) => {
              const cfg = severityConfig(alert.severity);
              return (
                <div key={alert.id} className="px-5 py-3">
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${cfg.dot} ring-4 ring-white`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900 truncate">{alert.title}</p>
                      <p className="text-xs text-slate-500 truncate">{alert.message}</p>
                      <p className="text-xs text-slate-400 mt-1">{timeAgo(alert.timestamp)}</p>
                    </div>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-bold ${cfg.badge}`}>
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h3 className="border-b border-slate-200 px-5 py-4 text-sm font-bold text-slate-900">Device Fleet Status</h3>
          <div className="divide-y divide-slate-100">
            {devices.map((dev) => (
              <div key={dev.id} className="flex items-center gap-4 px-5 py-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-lg">📡</div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900 truncate">{dev.name}</p>
                  <p className="text-xs text-slate-500 truncate">{dev.location} · {dev.type}</p>
                </div>
                <div className="text-right">
                  <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${
                    dev.status === "online"
                      ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                      : dev.status === "maintenance"
                      ? "bg-amber-50 text-amber-700 ring-amber-200"
                      : "bg-red-50 text-red-700 ring-red-200"
                  }`}>{dev.status.toUpperCase()}</span>
                  <p className="text-xs text-slate-400 mt-1">v{dev.firmwareVersion}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="border-b border-slate-200 px-5 py-4 text-sm font-bold text-slate-900">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3 p-4">
            {[
              { label: "Auth Scan", icon: "🔐", action: () => setView("authentication") },
              { label: "Enroll User", icon: "👤", action: () => setView("enrollment") },
              { label: "View Logs", icon: "📋", action: () => setView("logs") },
              { label: "Alerts", icon: "🔔", action: () => setView("alerts") },
            ].map((q) => (
              <button key={q.label} onClick={q.action}
                className="flex flex-col items-center gap-2 rounded-xl border border-slate-200 bg-white p-4 text-center transition-all hover:border-indigo-300 hover:shadow-md hover:bg-indigo-50">
                <span className="text-2xl">{q.icon}</span>
                <span className="text-xs font-semibold text-slate-700">{q.label}</span>
              </button>
            ))}
          </div>
          <div className="px-4 pb-4">
            <div className="rounded-lg bg-indigo-50 p-3">
              <p className="text-xs font-bold text-indigo-900">⚡ Audit Status</p>
              <p className="text-xs text-indigo-700 mt-1">
                Retention: <strong>{auditRetention} days</strong> · Encryption:{" "}
                <strong>{encryptionAtRest ? "AES-256" : "Disabled"}</strong>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );

  // ─────────────────────────────────────────────────────────────
  // View: Authentication
  // ─────────────────────────────────────────────────────────────
  const renderAuthentication = () => {
    const lockoutActive = lockoutUntil !== null && Date.now() < lockoutUntil;
    const lockoutRemaining = lockoutActive ? Math.max(0, Math.ceil((lockoutUntil - Date.now()) / 1000)) : 0;

    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Biometric Authentication</h2>
          <p className="text-sm text-slate-500 mt-1">Submit a biometric sample for identity verification and access control.</p>
        </div>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-6">
              <div className="mb-6">
                <div className="mx-auto h-64 w-full max-w-md overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 relative">
                  {authScanning && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="flex flex-col items-center">
                        <div className="relative">
                          <div className="h-24 w-24 rounded-full border-4 border-indigo-400 border-t-transparent animate-spin" />
                          <div className="absolute inset-3 rounded-full border-4 border-emerald-400 border-b-transparent animate-spin"
                            style={{ animationDirection: "reverse", animationDuration: "0.8s" }} />
                        </div>
                        <p className="mt-4 text-sm font-medium text-indigo-200">
                          {authConfidence < 100 ? "Analyzing biometric..." : "Processing..."}
                        </p>
                      </div>
                    </div>
                  )}
                  {!authScanning && !authResult && (
                    <div className="flex h-full flex-col items-center justify-center text-slate-400">
                      <span className="text-5xl mb-3">{BIOMETRIC_LABELS[authMethod].icon}</span>
                      <p className="text-sm">Ready to scan</p>
                      <p className="text-xs mt-1 text-slate-500">Select method and initiate scan</p>
                    </div>
                  )}
                  {!authScanning && authResult === "granted" && (
                    <div className="flex h-full flex-col items-center justify-center text-emerald-300">
                      <span className="text-6xl mb-3">✅</span>
                      <p className="text-xl font-bold">Access Granted</p>
                      <p className="text-sm mt-1">Verified: {authUserName}</p>
                      <p className="text-xs mt-2 text-emerald-400">Confidence: {authConfidence}%</p>
                    </div>
                  )}
                  {!authScanning && authResult === "denied" && (
                    <div className="flex h-full flex-col items-center justify-center text-red-300">
                      <span className="text-6xl mb-3">🚫</span>
                      <p className="text-xl font-bold">Access Denied</p>
                      <p className="text-sm mt-1">No matching identity found</p>
                      <p className="text-xs mt-2 text-red-400">Confidence: {authConfidence}%</p>
                    </div>
                  )}
                  {authScanning && (
                    <div
                      className="absolute inset-x-0 h-1 bg-indigo-400/80"
                      style={{
                        animation: "scanline 1.5s linear infinite",
                        boxShadow: "0 0 20px rgba(99,102,241,0.6)",
                      }}
                    />
                  )}
                  <style>{`@keyframes scanline { 0% { top: 0; } 50% { top: calc(100% - 2px); } 100% { top: 0; } }`}</style>
                </div>
              </div>
              <div className="mb-4">
                <label className="mb-2 block text-xs font-bold text-slate-500 uppercase tracking-wide">
                  Biometric Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(Object.keys(BIOMETRIC_LABELS) as BiometricType[]).map((m) => (
                    <button key={m}
                      onClick={() => { setAuthMethod(m); setAuthResult(null); setAuthConfidence(0); }}
                      className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                        authMethod === m
                          ? "border-indigo-600 bg-indigo-50 text-indigo-700"
                          : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                      }`} disabled={authScanning}>
                      <span>{BIOMETRIC_LABELS[m].icon}</span>{BIOMETRIC_LABELS[m].label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="rounded-lg bg-amber-50 border border-amber-100 px-4 py-3 flex items-start gap-3">
                <span className="text-amber-600 text-lg">🛡️</span>
                <div className="text-xs text-amber-800">
                  <p className="font-bold">Security Protocol Active</p>
                  <p className="mt-0.5">
                    Images processed on-device. No raw biometric data leaves this terminal.
                    MFA: {mfaRequired ? "REQUIRED for high-clearance entries" : "Not enforced"}.
                  </p>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={handleAuthScan}
                  disabled={authScanning || lockoutActive}
                  className={`${primaryBtn} text-base px-8 py-3`}
                >
                  {authScanning
                    ? <><span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin" /> Processing...</>
                    : lockoutActive ? <>🔒 Locked · {lockoutRemaining}s</>
                    : <>🔍 Initiate Scan</>}
                </button>
                {(authResult || lockoutActive) && (
                  <button onClick={() => { setAuthResult(null); setAuthConfidence(0); setAuthUserName(""); }}
                    className={secondaryBtn}>Reset</button>
                )}
              </div>
            </Card>
            {authResult === "granted" && mfaRequired && (
              <Card className="p-6 border-indigo-200 bg-indigo-50/50">
                <h3 className="text-sm font-bold text-indigo-900 mb-3">🔐 Secondary Verification</h3>
                <p className="text-xs text-indigo-700 mb-4">High-security area detected. Please complete MFA challenge.</p>
                <div className="grid grid-cols-2 gap-3">
                  <input type="text" readOnly defaultValue="847291"
                    className="rounded-lg border border-indigo-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
                  <button className={primaryBtn}>Verify OTP</button>
                </div>
              </Card>
            )}
          </div>
          <div className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-bold text-slate-900 mb-3">📡 Scanner Info</h3>
              <div className="space-y-2">
                {[
                  ["Device", "DEV-01"], ["Location", "Main Entrance"],
                  ["Firmware", "v4.2.1"], ["Status", "Online"],
                  ["Min Confidence", `${minConfidence}%`],
                ].map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">{k}</span>
                    <span className={`font-semibold ${k === "Status" ? "text-emerald-700" : "text-slate-900"}`}>{v}</span>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="p-4">
              <h3 className="text-sm font-bold text-slate-900 mb-3">⚖️ Active Policies</h3>
              <div className="space-y-2 text-xs">
                {[
                  `Lockout after ${lockoutThreshold} failed attempts`,
                  `Lockout duration: ${lockoutDuration} min`,
                  `MFA: ${mfaRequired ? "Enforced" : "Disabled"}`,
                  "Tamper Detection: Active",
                  "Encryption at Rest: AES-256",
                ].map((t) => (
                  <div key={t} className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-indigo-500" />
                    <span className="text-slate-700">{t}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────
  // View: Enrollment
  // ─────────────────────────────────────────────────────────────
  const renderEnrollment = () => {
    const enrolledCount = Object.values(enrollBiometrics).filter(Boolean).length;
    const requiredCount = 2;
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">User Enrollment</h2>
          <p className="text-sm text-slate-500 mt-1">
            Add a new identity to the biometric database. Minimum {requiredCount} biometric types required.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-6">
              <h3 className="text-sm font-bold text-slate-900 mb-4">
                📸 Biometric Capture ({enrolledCount}/{requiredCount} minimum enrolled)
              </h3>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
                {(Object.keys(BIOMETRIC_LABELS) as BiometricType[]).map((type) => {
                  const enrolled = enrollBiometrics[type];
                  const scanning = enrollScanning === type;
                  return (
                    <div key={type}
                      className={`rounded-xl border p-4 transition-all ${
                        enrolled ? "border-emerald-200 bg-emerald-50"
                        : scanning ? "border-indigo-200 bg-indigo-50"
                        : "border-slate-200 bg-white hover:border-slate-300"
                      }`}>
                      <div className="mb-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{BIOMETRIC_LABELS[type].icon}</span>
                          <span className="text-sm font-bold text-slate-900">{BIOMETRIC_LABELS[type].label}</span>
                        </div>
                        {enrolled && (
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 text-white text-xs">✓</span>
                        )}
                      </div>
                      {scanning ? (
                        <div className="space-y-2">
                          <div className="h-2 w-full rounded-full bg-slate-200 overflow-hidden">
                            <div className="h-full bg-indigo-500 transition-all duration-100"
                              style={{ width: `${enrollProgress[type] ?? 0}%` }} />
                          </div>
                          <p className="text-xs text-center text-slate-500">Scanning...</p>
                        </div>
                      ) : (
                        <button onClick={() => scanBiometricForEnroll(type)} disabled={enrolled}
                          className={`w-full rounded-lg px-3 py-2 text-xs font-semibold transition ${
                            enrolled
                              ? "bg-emerald-100 text-emerald-700 cursor-default"
                              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                          }`}>
                          {enrolled ? "✓ Enrolled" : "Start Capture"}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>
            <Card className="p-6">
              <h3 className="text-sm font-bold text-slate-900 mb-4">📋 Identity Details</h3>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-500">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input value={enrollName} onChange={(e) => setEnrollName(e.target.value)}
                    placeholder="Enter full legal name"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-500">Role</label>
                  <select value={enrollRole} onChange={(e) => setEnrollRole(e.target.value as UserIdentity["role"])}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none">
                    {ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-500">Department</label>
                  <select value={enrollDept} onChange={(e) => setEnrollDept(e.target.value)}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none">
                    {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-bold text-slate-500">Clearance Level</label>
                  <select value={enrollClearance} onChange={(e) => setEnrollClearance(Number(e.target.value) as 1|2|3|4|5)}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none">
                    {CLEARANCE_LEVELS.map((c) => <option key={c.level} value={c.level}>{c.label}</option>)}
                  </select>
                </div>
              </div>
            </Card>
            <div className="flex items-center justify-end gap-3">
              <button onClick={() => setView("users")} className={secondaryBtn}>Cancel</button>
              <button onClick={handleEnroll} disabled={!enrollName.trim() || enrolledCount < requiredCount}
                className={primaryBtn}>Register User →</button>
            </div>
          </div>
          <div className="space-y-4">
            <Card className="p-4">
              <h3 className="text-sm font-bold text-slate-900 mb-2">📝 Enrollment Guidelines</h3>
              <ul className="space-y-2 text-xs text-slate-600">
                <li>• Capture biometrics in a well-lit environment.</li>
                <li>• Remove glasses, hats, or masks before facial capture.</li>
                <li>• Fingerprints should be clean and dry.</li>
                <li>• Eyes must be open and visible for iris scan.</li>
                <li>• Minimum 2 biometric types recommended.</li>
              </ul>
            </Card>
            <Card className="p-4">
              <h3 className="text-sm font-bold text-slate-900 mb-2">🔒 Privacy Notice</h3>
              <p className="text-xs text-slate-600">
                All biometric data is encrypted with AES-256 and stored in secure vaults.
                Raw templates are never shared across nodes.
                Retention governed by {auditRetention}-day audit policy.
              </p>
            </Card>
          </div>
        </div>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────
  // View: Users
  // ─────────────────────────────────────────────────────────────
  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">User Database</h2>
          <p className="text-sm text-slate-500 mt-1">
            {users.length} enrolled · {users.filter((u) => u.status === "active").length} active
          </p>
        </div>
        <button onClick={() => setView("enrollment")} className={primaryBtn}>+ New Enrollment</button>
      </div>
      {!selectedUser ? (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {users.map((user) => (
            <button key={user.id} onClick={() => { setSelectedUser(user); setUserTab("info"); }}
              className="rounded-xl border border-slate-200 bg-white p-5 text-left shadow-sm transition-all hover:border-indigo-300 hover:shadow-md">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-lg font-bold text-white">
                  {user.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-900 truncate">{user.name}</p>
                  <p className="text-xs text-slate-500 truncate">{user.badgeNumber}</p>
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${
                  user.status === "active" ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                  : user.status === "suspended" ? "bg-red-50 text-red-700 ring-red-200"
                  : "bg-amber-50 text-amber-700 ring-amber-200"
                }`}>{user.status}</span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div><p className="text-slate-400">Role</p><p className="font-semibold text-slate-700 capitalize">{user.role}</p></div>
                <div><p className="text-slate-400">Dept</p><p className="font-semibold text-slate-700 truncate">{user.department}</p></div>
                <div><p className="text-slate-400">Clearance</p><p className="font-semibold text-slate-700">Level {user.clearanceLevel}</p></div>
                <div><p className="text-slate-400">Biometrics</p><p className="font-semibold text-slate-700">{Object.values(user.biometrics).filter(Boolean).length}/5</p></div>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          <button onClick={() => setSelectedUser(null)} className={ghostBtn}>← Back to user list</button>
          <Card>
            <div className="flex items-center gap-6 border-b border-slate-200 px-6 py-5">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-2xl font-bold text-white shadow-lg">
                {selectedUser.name.split(" ").map(n => n[0]).join("")}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-lg font-bold text-slate-900">{selectedUser.name}</h3>
                <p className="text-sm text-slate-500">{selectedUser.badgeNumber} · {selectedUser.department}</p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <span className={`rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${
                    selectedUser.status === "active" ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
                    : selectedUser.status === "suspended" ? "bg-red-50 text-red-700 ring-red-200"
                    : "bg-amber-50 text-amber-700 ring-amber-200"
                  }`}>{selectedUser.status}</span>
                  <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-bold text-indigo-700 ring-1 ring-indigo-200">{selectedUser.role.toUpperCase()}</span>
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-700 ring-1 ring-slate-200">CLEARANCE L{selectedUser.clearanceLevel}</span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => {
                    const newStatus = selectedUser.status === "suspended" ? "active" : "suspended";
                    setUsers((prev) => prev.map((u) => u.id === selectedUser.id ? { ...u, status: newStatus as "active" | "suspended" } : u));
                    setSelectedUser((p) => p ? { ...p, status: newStatus as "active" | "suspended" } : null);
                  }}
                  className={`${selectedUser.status === "active" ? dangerBtn : primaryBtn}`}>
                  {selectedUser.status === "active" ? "Suspend User" : "Reactivate User"}
                </button>
                <button onClick={() => { setUsers((prev) => prev.filter((u) => u.id !== selectedUser.id)); setSelectedUser(null); }}
                  className={dangerBtn}>Delete User</button>
              </div>
            </div>
            <div className="flex border-b border-slate-200 px-6">
              {([
                ["info", "ℹ️"],
                ["logs", "📋"],
                ["settings", "🔧"],
              ] as const).map(([tab, icon]) => (
                <button key={tab} onClick={() => setUserTab(tab)}
                  className={`px-4 py-3 text-sm font-semibold transition-colors ${
                    userTab === tab
                      ? "border-b-2 border-indigo-600 text-indigo-700"
                      : "text-slate-500 hover:text-slate-900"
                  }`}>
                  {icon} {tab.toUpperCase()}
                </button>
              ))}
            </div>
            <div className="p-6">
              {userTab === "info" && (
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="rounded-lg bg-slate-50 p-4">
                    <h4 className="text-xs font-bold text-slate-500 uppercase">Personal Information</h4>
                    <dl className="mt-3 space-y-2 text-sm">
                      <div><dt className="text-slate-400">Full Name</dt><dd className="font-semibold text-slate-900">{selectedUser.name}</dd></div>
                      <div><dt className="text-slate-400">User ID</dt><dd className="font-mono text-slate-900">{selectedUser.id}</dd></div>
                      <div><dt className="text-slate-400">Badge Number</dt><dd className="font-mono text-slate-900">{selectedUser.badgeNumber}</dd></div>
                    </dl>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-4">
                    <h4 className="text-xs font-bold text-slate-500 uppercase">Access & Security</h4>
                    <dl className="mt-3 space-y-2 text-sm">
                      <div><dt className="text-slate-400">Role</dt><dd className="font-semibold text-slate-900 capitalize">{selectedUser.role}</dd></div>
                      <div><dt className="text-slate-400">Department</dt><dd className="font-semibold text-slate-900">{selectedUser.department}</dd></div>
                      <div><dt className="text-slate-400">Clearance Level</dt><dd className="font-semibold text-slate-900">Level {selectedUser.clearanceLevel}</dd></div>
                    </dl>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-4 md:col-span-2">
                    <h4 className="text-xs font-bold text-slate-500 uppercase">Enrolled Biometric Modalities</h4>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {(Object.keys(BIOMETRIC_LABELS) as BiometricType[]).map((type) => (
                        <span key={type} className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${
                          selectedUser.biometrics[type]
                            ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"
                            : "bg-slate-100 text-slate-400"
                        }`}>
                          {BIOMETRIC_LABELS[type].icon} {BIOMETRIC_LABELS[type].label}
                          {selectedUser.biometrics[type] && " ✓"}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {userTab === "logs" && (
                <div className="space-y-2">
                  {logs.filter((l) => l.userId === selectedUser.id).length === 0
                    ? <p className="py-8 text-center text-sm text-slate-400">No access logs found for this user.</p>
                    : logs.filter((l) => l.userId === selectedUser.id)
                        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                        .map((log) => (
                          <div key={log.id} className="flex items-center gap-4 rounded-lg border border-slate-100 p-3">
                            <span className="text-lg">{log.result === "granted" ? "✅" : log.result === "denied" ? "❌" : "⏳"}</span>
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-semibold text-slate-900 capitalize">
                                {BIOMETRIC_LABELS[log.method].label} · {log.point}
                              </p>
                              <p className="text-xs text-slate-500">{formatDate(log.timestamp)}</p>
                            </div>
                            <span className={`rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${accessResultBadge(log.result)}`}>
                              {log.result}
                            </span>
                          </div>
                        ))
                  }
                </div>
              )}
              {userTab === "settings" && (
                <div className="space-y-4">
                  <div className="rounded-lg bg-slate-50 p-4">
                    <h4 className="text-sm font-bold text-slate-900 mb-2">Manage User</h4>
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                      <button onClick={() => {
                        setUsers((prev) => prev.filter((u) => u.id !== selectedUser.id));
                        setSelectedUser(null);
                      }} className={dangerBtn}>Delete User</button>
                      <button className={secondaryBtn}>Send Reset Instructions</button>
                    </div>
                  </div>
                  <div className="rounded-lg bg-amber-50 p-4 border border-amber-100">
                    <p className="text-xs text-amber-800">
                      ⚠️ All modifications are logged and tagged with the operator's identity.
                      Audit trail is not reversible.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );

  // ─────────────────────────────────────────────────────────────
  // View: Logs
  // ─────────────────────────────────────────────────────────────
  const renderLogs = () => {
    const filteredLogs = useMemo(() => {
      return logs
        .filter((l) => {
          if (logFilter.result && l.result !== logFilter.result) return false;
          if (logFilter.method && l.method !== logFilter.method) return false;
          if (logSearch.trim()) {
            const q = logSearch.toLowerCase();
            return l.userName.toLowerCase().includes(q)
              || l.point.toLowerCase().includes(q)
              || l.deviceId.toLowerCase().includes(q)
              || l.id.toLowerCase().includes(q);
          }
          return true;
        })
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [logs, logFilter, logSearch]);

    return (
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Access Logs</h2>
            <p className="text-sm text-slate-500 mt-1">Showing {filteredLogs.length} of {logs.length} records</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <input value={logSearch} onChange={(e) => setLogSearch(e.target.value)}
              placeholder="Search logs..." className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
            <select value={logFilter.result || ""} onChange={(e) => setLogFilter((f) => ({ ...f, result: e.target.value }))}
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none">
              <option value="">All Results</option>
              <option value="granted">Granted</option>
              <option value="denied">Denied</option>
              <option value="pending">Pending</option>
            </select>
            <select value={logFilter.method || ""} onChange={(e) => setLogFilter((f) => ({ ...f, method: e.target.value }))}
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none">
              <option value="">All Methods</option>
              {(Object.keys(BIOMETRIC_LABELS) as BiometricType[]).map((m) => (
                <option key={m} value={m}>{BIOMETRIC_LABELS[m].label}</option>
              ))}
            </select>
            {(logFilter.result || logFilter.method || logSearch) && (
              <button onClick={() => { setLogFilter({}); setLogSearch(""); }} className={ghostBtn}>Clear</button>
            )}
          </div>
        </div>
        <Card><div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                {(["Time", "User", "Method", "Point", "Device", "Confidence", "Result", "Reason"] as const).map((h) => (
                  <th key={h} className="px-5 py-3 text-xs font-bold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3 text-xs text-slate-600 whitespace-nowrap">{formatDate(log.timestamp)}</td>
                  <td className="px-5 py-3">
                    <p className="font-semibold text-slate-900 truncate max-w-[150px]">{log.userName}</p>
                    <p className="text-xs text-slate-400 font-mono">{log.userId}</p>
                  </td>
                  <td className="px-5 py-3 text-xs text-slate-700 capitalize">
                    {BIOMETRIC_LABELS[log.method].icon} {BIOMETRIC_LABELS[log.method].label}
                  </td>
                  <td className="px-5 py-3 text-xs text-slate-700">{log.point}</td>
                  <td className="px-5 py-3 text-xs text-slate-500 font-mono">{log.deviceId}</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${confidenceColor(log.confidence)}`}>
                      {log.confidence.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ring-1 ${accessResultBadge(log.result)}`}>
                      {log.result}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-xs text-slate-500 max-w-[200px] truncate">{log.reason || "—"}</td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr><td colSpan={8} className="px-5 py-12 text-center text-sm text-slate-400">No log entries match your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div></Card>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────
  // View: Alerts
  // ─────────────────────────────────────────────────────────────
  const renderAlerts = () => {
    const unresolvedCount = alerts.filter((a) => !a.resolved).length;
    const counts = {
      critical: alerts.filter((a) => !a.resolved && a.severity === "critical").length,
      warning: alerts.filter((a) => !a.resolved && a.severity === "warning").length,
      info: alerts.filter((a) => !a.resolved && a.severity === "info").length,
    };
    return (
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Alert Center</h2>
            <p className="text-sm text-slate-500 mt-1">{unresolvedCount} unresolved · {alerts.filter((a) => a.resolved).length} resolved</p>
          </div>
          <div className="flex items-center gap-2">
            {([
              ["critical", counts.critical],
              ["warning", counts.warning],
              ["info", counts.info],
            ] as const).map(([sev, c]) => (
              <span key={sev} className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold ${severityConfig(sev).badge}`}>
                {c} {sev}
              </span>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            {alerts.length === 0
              ? <Card className="p-12 text-center"><p className="text-4xl mb-3">🎉</p><p className="text-sm font-semibold text-slate-700">No alerts active</p><p className="text-xs text-slate-400 mt-1">System is operating normally.</p></Card>
              : alerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((alert) => {
                  const cfg = severityConfig(alert.severity);
                  return (
                    <Card key={alert.id}
                      className={`cursor-pointer transition-all hover:shadow-md ${selectedAlert?.id === alert.id ? "ring-2 ring-indigo-500" : ""} ${alert.resolved ? "opacity-60" : ""}`}
                      onClick={() => setSelectedAlert(alert)}>
                      <div className={`flex items-start gap-4 p-5 rounded-xl ${cfg.bg}`}>
                        <div className={`mt-0.5 h-2.5 w-2.5 shrink-0 rounded-full ${cfg.dot} ${!alert.resolved ? "animate-pulse" : ""} ring-4 ring-white`} />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <span className={`text-xs font-bold ${cfg.text}`}>[{alert.severity.toUpperCase()}]</span>
                            <span className="text-xs text-slate-400">{timeAgo(alert.timestamp)}</span>
                          </div>
                          <h4 className="mt-1 text-sm font-bold text-slate-900">{alert.title}</h4>
                          <p className="mt-1 text-xs text-slate-600">{alert.message}</p>
                          <p className="mt-1 text-xs text-slate-400">Source: {alert.source}</p>
                          {alert.metadata && (
                            <div className="mt-2 flex flex-wrap gap-2">
                              {Object.entries(alert.metadata).map(([k, v]) => (
                                <span key={k} className="rounded bg-white/70 px-2 py-0.5 text-xs font-mono text-slate-600">{k}: {v}</span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  );
                })
            }
          </div>
          <div>
            {selectedAlert ? (
              <Card className="sticky top-6 p-5">
                <h3 className="text-sm font-bold text-slate-900 mb-3">Alert Details</h3>
                <dl className="space-y-3 text-sm">
                  <div><dt className="text-slate-400 text-xs">Alert ID</dt><dd className="font-mono text-slate-900">{selectedAlert.id}</dd></div>
                  <div><dt className="text-slate-400 text-xs">Severity</dt>
                    <dd><span className={`rounded-full px-2 py-0.5 text-xs font-bold ${severityConfig(selectedAlert.severity).badge}`}>{selectedAlert.severity.toUpperCase()}</span></dd>
                  </div>
                  <div><dt className="text-slate-400 text-xs">Status</dt>
                    <dd className={`${selectedAlert.resolved ? "text-emerald-700" : "text-red-700"} font-semibold`}>
                      {selectedAlert.resolved ? "✓ Resolved" : "⏳ Unresolved"}
                    </dd>
                  </div>
                  <div><dt className="text-slate-400 text-xs">Timestamp</dt><dd className="text-slate-900">{formatDate(selectedAlert.timestamp)}</dd></div>
                  <div><dt className="text-slate-400 text-xs">Source</dt><dd className="text-slate-900">{selectedAlert.source}</dd></div>
                  <div><dt className="text-slate-400 text-xs">Description</dt><dd className="text-slate-700">{selectedAlert.message}</dd></div>
                  {selectedAlert.metadata && (
                    <div><dt className="text-slate-400 text-xs">Metadata</dt>
                      <dd><pre className="mt-1 rounded bg-slate-50 p-2 text-xs font-mono text-slate-700">{JSON.stringify(selectedAlert.metadata, null, 2)}</pre></dd>
                    </div>
                  )}
                </dl>
                {!selectedAlert.resolved && (
                  <button onClick={() => {
                    setAlerts((prev) => prev.map((a) => a.id === selectedAlert.id ? { ...a, resolved: true } : a));
                    setSelectedAlert((p) => (p ? { ...p, resolved: true } : null));
                  }} className="mt-4 w-full rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700">
                    Mark as Resolved
                  </button>
                )}
              </Card>
            ) : (
              <Card className="p-5 text-center"><p className="text-sm text-slate-400">Select an alert to view details.</p></Card>
            )}
          </div>
        </div>
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────
  // View: Settings
  // ─────────────────────────────────────────────────────────────
  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-slate-900">System Settings</h2>
        <p className="text-sm text-slate-500 mt-1">Configure security policies, alert rules, and system behavior.</p>
      </div>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <h3 className="mb-4 text-sm font-bold text-slate-900">🛡️ Security Policies</h3>
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-500">Lockout after failed attempts</label>
              <input type="number" min={1} max={20} value={lockoutThreshold}
                onChange={(e) => setLockoutThreshold(parseInt(e.target.value) || 3)}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
              <p className="mt-1 text-xs text-slate-400">Account locked for {lockoutThreshold} consecutive failed scans.</p>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-500">Lockout duration (minutes)</label>
              <input type="number" min={1} max={120} value={lockoutDuration}
                onChange={(e) => setLockoutDuration(parseInt(e.target.value) || 5)}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-500">Minimum confidence threshold (%)</label>
              <input type="number" min={1} max={100} value={minConfidence}
                onChange={(e) => setMinConfidence(parseInt(e.target.value) || 75)}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "MFA Required", value: mfaRequired, set: setMfaRequired, desc: "Multi-factor auth for Level 4+" },
                { label: "Auto Lock", value: autoLock, set: setAutoLock, desc: "Auto-lock after 5 min idle" },
              ].map((t) => (
                <div key={t.label} className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-700">{t.label}</p>
                    <button onClick={() => t.set((p: boolean) => !p)}
                      className={`relative h-5 w-9 rounded-full transition-colors ${t.value ? "bg-indigo-600" : "bg-slate-300"}`}>
                      <span className={`absolute top-0.5 inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${t.value ? "left-4" : "left-0.5"}`} />
                    </button>
                  </div>
                  <p className="mt-1 text-xs text-slate-400">{t.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <h3 className="mb-4 text-sm font-bold text-slate-900">🔒 Data & Compliance</h3>
          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-500">Audit Log Retention (days)</label>
              <input type="number" min={7} max={365} value={auditRetention}
                onChange={(e) => setAuditRetention(parseInt(e.target.value) || 90)}
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none" />
              <p className="mt-1 text-xs text-slate-400">Older logs are purged per GDPR/CCPA compliance.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: "AES-256 Encryption", value: encryptionAtRest, set: setEncryptionAtRest, desc: "At-rest data protection" },
                { label: "Tamper Detection", value: tamperDetection, set: setTamperDetection, desc: "HSMS calibrations" },
              ].map((t) => (
                <div key={t.label} className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-700">{t.label}</p>
                    <button onClick={() => t.set((p: boolean) => !p)}
                      className={`relative h-5 w-9 rounded-full transition-colors ${t.value ? "bg-indigo-600" : "bg-slate-300"}`}>
                      <span className={`absolute top-0.5 inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${t.value ? "left-4" : "left-0.5"}`} />
                    </button>
                  </div>
                  <p className="mt-1 text-xs text-slate-400">{t.desc}</p>
                </div>
              ))}
            </div>
            <div className="rounded-lg bg-indigo-50 p-4 border border-indigo-100">
              <h4 className="text-xs font-bold text-indigo-900">📜 Compliance Summary</h4>
              <ul className="mt-2 space-y-1 text-xs text-indigo-800">
                <li>✓ GDPR Article 9 — Biometric data classification</li>
                <li>✓ SOC 2 Type II controls</li>
                <li>✓ ISO/IEC 27001 aligned</li>
                <li>✓ ISO/IEC 19794-5 biometric interchange</li>
                <li>✓ FIDO2 & NIST SP 800-63-3 ready</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>

      {/* Alert Rules */}
      <Card>
        <h3 className="mb-4 text-sm font-bold text-slate-900 px-6 pt-6">🔔 Alert Rules Engine</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200">
                {(["Rule ID", "Name", "Description", "Severity", "Triggers", "Enabled", "Action"] as const).map((h) => (
                  <th key={h} className="px-5 py-3 text-xs font-bold text-slate-500 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {alertRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-mono text-xs text-slate-600">{rule.id}</td>
                  <td className="px-5 py-3 font-semibold text-slate-900">{rule.name}</td>
                  <td className="px-5 py-3 text-xs text-slate-500">{rule.description}</td>
                  <td className="px-5 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${severityConfig(rule.severity).badge}`}>
                      {rule.severity.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-xs font-semibold text-slate-700">{rule.triggerCount} this month</td>
                  <td className="px-5 py-3">
                    <button onClick={() => setAlertRules((prev) => prev.map((r) => r.id === rule.id ? { ...r, enabled: !r.enabled } : r))}
                      className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${rule.enabled ? "bg-indigo-600" : "bg-slate-300"}`}>
                      <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${rule.enabled ? "translate-x-4" : "translate-x-0.5"}`} />
                    </button>
                  </td>
                  <td className="px-5 py-3">
                    <span className={xsBtn + " bg-slate-100 text-slate-600 hover:bg-slate-200"}>Edit</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="flex items-center justify-end gap-3">
        {settingsSaved && (
          <span className="text-sm font-semibold text-emerald-600">✓ Settings saved successfully</span>
        )}
        <button onClick={() => { setSettingsSaved(true); setTimeout(() => setSettingsSaved(false), 3000); }}
          className={primaryBtn}>💾 Save All Settings</button>
      </div>
    </div>
  );

  // ─────────────────────────────────────────────────────────────
  // Main Layout Render
  // ─────────────────────────────────────────────────────────────
  return (
    <div className="flex min-h-screen bg-slate-50">
      {sidebar}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 lg:hidden" onClick={() => setSidebarOpen(false)}>
          <div className="h-full w-64" onClick={(e: React.MouseEvent) => e.stopPropagation()}>{sidebar}</div>
        </div>
      )}
      <main className="min-h-screen flex-1 overflow-y-auto">
        <header className="sticky top-0 z-10 border-b border-slate-200 bg-white/80 px-6 py-3 backdrop-blur-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className={ghostBtn} title="Menu">
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
              <div>
                <h2 className="text-sm font-bold text-slate-900 capitalize">
                  {view === "dashboard" ? "Command Dashboard" : view}
                </h2>
                <p className="text-xs text-slate-400">
                  {new Date().toLocaleString("en-US", {
                    weekday: "short", month: "short", day: "numeric",
                    hour: "2-digit", minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={() => setView("alerts")} className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100">
                <span className="text-xl">🔔</span>
                {systemStats.alertsCount > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                    {systemStats.alertsCount}
                  </span>
                )}
              </button>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-sm font-bold text-white shadow">AD</div>
            </div>
          </div>
        </header>
        <div className="p-6 max-w-[1400px]">
          {view === "dashboard" && renderDashboard()}
          {view === "authentication" && renderAuthentication()}
          {view === "enrollment" && renderEnrollment()}
          {view === "users" && renderUsers()}
          {view === "logs" && renderLogs()}
          {view === "alerts" && renderAlerts()}
          {view === "settings" && renderSettings()}
        </div>
        <footer className="border-t border-slate-200 bg-white px-6 py-3">
          <div className="flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-4">
              <span className="font-semibold text-slate-700">BioShield™ v4.2.1</span>
              <span>© {new Date().getFullYear()} All rights reserved.</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> All systems nominal</span>
              <span className="hidden md:inline">Clusters: 3</span>
              <span className="hidden md:inline">Regions: US-E, US-W, EU</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
